
var map = L.map('map').setView([39.5, -98.35], 5); // Center on US

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 18,
}).addTo(map);

fetch('data/ai_zones.json')
  .then(res => res.json())
  .then(data => {
    L.geoJSON(data, {
      style: {
        color: 'gold',
        weight: 2,
        opacity: 0.7
      },
      onEachFeature: function (feature, layer) {
        const props = feature.properties;
        layer.bindPopup(
          `<b>${props.name}</b><br>` +
          `AI Prediction: ${props.ai_interpretation}<br>` +
          `Probability Score: ${props.ai_probability_score}%`
        );
      }
    }).addTo(map);
  });
